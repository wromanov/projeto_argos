# Camera Inventory Design System

Version 1.0.1 · `VISUAL_BASELINE_APPROVED`

Reusable, agent-ready design-system package for web applications that inventory and operate CCTV cameras. It is built on the visual direction approved in the referenced conversation: **Corporate Tech / Infrastructure** with shadcn/ui primitives, a petrol-blue sidebar, blue-gray surfaces, a corporate blue primary, teal accents, and status colors reserved for operational meaning.

The package is intentionally framework-light. It gives a vibe-coding agent the decisions it must not re-invent: tokens, density, component contracts, page composition, accessibility, migration order, and an acceptance checklist.

## What is included

- `DESIGN_SYSTEM_SPEC.md` — product and visual contract.
- `DESIGN_TOKENS.md` — semantic token dictionary and usage rules.
- `COMPONENT_GUIDELINES.md` — primitives and domain component contracts.
- `PAGE_PATTERNS.md` — dashboard, inventory list, detail sheet, and responsive patterns.
- `AI_IMPLEMENTATION_RULES.md` — rules for consistent implementation by Codex or other agents.
- `ACCESSIBILITY.md` — keyboard, focus, contrast, motion, and screen-reader requirements.
- `MIGRATION.md` — adoption path for an existing shadcn/Tailwind project.
- `VISUAL_ACCEPTANCE_CHECKLIST.md` — release-gate checklist.
- `tokens/camera-inventory.css` — ready-to-import shadcn CSS variables and product tokens.
- `tokens/tailwind.preset.ts` — Tailwind preset mapping semantic tokens to utilities.
- `tokens/status.ts` — typed status values and metadata.
- `examples/` — React/TypeScript examples for all camera-inventory domain components.
- `package-manifest.json` — machine-readable package metadata for an AI agent.
- `PRODUCT_DESIGN_CONTEXT.md` — concise design brief and evidence trail used by the Product Design workflow.
- `prototype/` — runnable React/Vite reference implementation with the approved executive dashboard, camera detail sheet, and responsive viewport behavior.

## Baseline and scope

The source conversation contained an approved image reference, but the image asset itself was not available to this workspace. The package therefore encodes the approved visual baseline as a durable textual contract rather than claiming pixel-perfect extraction. The baseline is:

```text
Sidebar:       #123047 petrol blue
Main surface:  #F4F7FA blue-gray
Cards:         #FAFCFE near-white blue
Primary:       #2563A6 corporate blue
Accent:        #DFF3F2 / #0F6F71 teal
Typography:    Inter
Icons:         Lucide
Density:       moderate, operationally legible
Status:        online / warning / offline / maintenance / disabled / info
```

Do not treat the baseline as permission to add gradients, neon, black-and-white defaults, or decorative status colors.

## Quick adoption

1. Copy `tokens/camera-inventory.css` into the application global stylesheet and load Inter.
2. Add `tokens/tailwind.preset.ts` to `tailwind.config.ts` (or copy its theme entries when using Tailwind v4).
3. Keep shadcn/ui primitives in `components/ui` and place the domain components in `components/camera-inventory`.
4. Start with the examples in `examples/components` and replace only data access and routing.
5. Run the acceptance checklist before adding new page-specific styles.

The included prototype is an implementation reference, not a replacement for the tokens and component contracts. Its latest responsive behavior keeps the desktop shell inside the viewport, contains vertical scrolling in the content region, removes table overflow at the tested desktop size, and simplifies secondary table columns on narrow screens.

## Preferred stack

React + TypeScript + Tailwind CSS + shadcn/ui + Lucide Icons + TanStack Table. MUI, Ant Design, or another full visual system should not be introduced unless the project documents a specific capability gap and an approved migration boundary.

## Agent handoff

Give an implementation agent this folder as context. The shortest reliable instruction is:

> Implement the requested screen using `AI_IMPLEMENTATION_RULES.md`, `DESIGN_TOKENS.md`, and the relevant pattern in `PAGE_PATTERNS.md`. Reuse the domain components and shadcn primitives. Do not invent colors, spacing, typography, or component variants. If a requirement is missing, choose the closest existing token or ask before adding a new one.

## License and ownership

This package is a project-local specification. Copy it into the target repository and update `package-manifest.json` when the product deliberately changes its visual language.
