# Visual Acceptance Checklist

Use this as a release gate for every new route or significant component.

## Baseline

- [ ] Canvas uses `#F4F7FA` through the background token.
- [ ] Cards/table surfaces use `#FAFCFE` and borders use `#D8E2EA`.
- [ ] Sidebar uses `#123047`; hover/active states are `#1A405B` / `#2563A6`.
- [ ] Primary action uses `#2563A6`; hover uses `#1D4F86`.
- [ ] Inter and Lucide are used.

## Consistency

- [ ] No raw color, arbitrary spacing, new font, or new radius was introduced.
- [ ] Existing shadcn primitives and domain components were reused.
- [ ] Status colors appear only for operational meaning.
- [ ] Loading, empty, error, disabled, and responsive states exist.

## Data operations

- [ ] Search and filters are keyboard reachable and clearable.
- [ ] Table sorting, selection, and pagination are announced and stable.
- [ ] Detail sheet preserves context and restores focus.
- [ ] Stale data displays its last-sync time.

## Accessibility

- [ ] Contrast and focus checks pass.
- [ ] Status has text/icon in addition to color.
- [ ] Icon-only controls have accessible names.
- [ ] Touch targets are at least 44px on mobile.
- [ ] Reduced motion is respected.

## Agent handoff

- [ ] Implementation names the pattern and tokens used.
- [ ] Any new variant/token is documented with a reason.
- [ ] A second agent could reproduce the layout without guessing.

