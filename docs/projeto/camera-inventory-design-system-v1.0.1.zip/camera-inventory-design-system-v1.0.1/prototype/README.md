# Camera Health Prototype

This folder is a runnable visual reference for the Camera Inventory Design System.

It demonstrates the approved executive inventory layout, semantic status colors, the right-side camera detail sheet, operator identity spacing, and the responsive viewport behavior documented in the parent package.

## Included reference behavior

- Desktop shell is contained within the viewport; only the main content region scrolls vertically.
- Attention and inventory tables do not introduce horizontal overflow at the reference desktop size.
- Narrow screens keep the header usable and collapse secondary table columns so the content stays within the viewport.
- Selecting a camera opens the detail sheet with preview, status, breadcrumb, network, VMS, activity, and actions.

The source of truth for agent implementation remains the parent package documents, especially `AI_IMPLEMENTATION_RULES.md`, `DESIGN_TOKENS.md`, and `PAGE_PATTERNS.md`.
