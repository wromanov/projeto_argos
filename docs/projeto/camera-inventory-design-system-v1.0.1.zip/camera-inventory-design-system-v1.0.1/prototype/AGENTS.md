# Prototype Instructions

## Durable design decisions

- Use the approved Corporate Tech / Infrastructure direction from the Camera Inventory Design System.
- Keep the executive summary band concise: availability, total cameras, attention, offline, and maintenance with trend context.
- Clicking an alert or inventory row opens a right-side camera detail sheet with a live preview, status, location, network, VMS, last activity, and actions.
- Preserve the semantic palette: online #16A36A, warning #E59B22, offline #D64545, maintenance #7C5CC4, disabled #81909C, info #3B82C4.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.
