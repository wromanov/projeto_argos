# Component Guidelines

The component system has three layers: shadcn primitives, product composites, and camera-domain components. Domain components must remain composable and typed; they should not own data fetching or routing.

## Composition rules

- Use shadcn `Button`, `Badge`, `Card`, `Input`, `Select`, `Sheet`, `Table`, `Breadcrumb`, and `Tooltip` as the primitive layer.
- Use Lucide icons at 16–20px in dense controls and 20–24px in cards.
- Keep component variants finite and named. Do not add ad-hoc boolean styling props when a variant communicates intent.
- Use `data-slot` attributes for stable visual selectors in tests.
- Components render loading, empty, disabled, and error states explicitly where relevant.

## Domain components

### `CameraStatusBadge`

Props: `status`, optional `label`, `showIcon`, `size`. It renders a dot/icon plus visible label and uses the typed status map. It must not accept arbitrary color classes.

### `CameraTable`

Props: typed camera rows, column visibility, sorting, pagination, selection, and row activation. Built on TanStack Table and shadcn Table. The default columns prioritize name, IP, location, model, last seen, and status. On mobile, hide secondary columns and preserve a status-first row summary.

### `CameraHealthCard`

Shows a count or percentage plus a health label. It accepts a semantic status and optional trend, but trend color cannot override the status meaning.

### `InventoryFilters`

Search, location, status, manufacturer, VMS, and “only attention required” controls. Filters are URL-serializable, keyboard reachable, and expose a clear-all action when active.

### `CameraDetailSheet`

Quick inspection surface opened from a row/card. It groups identity, status, network, VMS, and location. Deep edits link to a routed detail page. The sheet must trap focus and restore focus to its trigger.

### `NetworkInfo`

Displays IP, MAC, VLAN, switch, port, and connectivity timestamps. Sensitive values may be masked by the product; the component must support copy buttons with accessible labels.

### `VmsStatus`

Displays VMS name, server, stream state, and last synchronization. It uses info/online/warning/offline semantics, not brand colors.

### `LocationBreadcrumb`

Renders site/building/floor/area context and makes each ancestor navigable where a route exists.

### `InventoryKpiCard`

Metric card with label, value, optional description, and optional status. It supports a compact variant for dashboard rows and a default variant for primary metrics.

## States every composite must define

`default`, `hover`, `focus-visible`, `pressed`, `disabled`, `loading`, `empty`, `error`, and `responsive`. Data-heavy components additionally define `selected`, `sorted`, `filtered`, and `stale`.

