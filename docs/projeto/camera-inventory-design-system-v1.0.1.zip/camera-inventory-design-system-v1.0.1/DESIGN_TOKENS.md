# Design Tokens

All UI code consumes semantic tokens. Hex values are documented for design review; implementation should use CSS variables or Tailwind semantic utilities.

## Brand and structural tokens

| Token | Value | Use |
| --- | --- | --- |
| `background` | `#F4F7FA` | application canvas |
| `foreground` | `#172B3A` | primary text and icons |
| `surface` | `#FAFCFE` | cards and table containers |
| `surface-elevated` | `#FFFFFF` | sheets, dialogs, popovers |
| `primary` | `#2563A6` | primary actions, focus, links |
| `primary-hover` | `#1D4F86` | primary hover/pressed state |
| `primary-foreground` | `#FFFFFF` | content on primary |
| `secondary` | `#E8F2FA` | secondary fills and selected rows |
| `secondary-foreground` | `#1D4F86` | content on secondary |
| `accent` | `#DFF3F2` | teal tint and positive contextual emphasis |
| `accent-foreground` | `#0F6F71` | content on accent |
| `muted` | `#EAF0F4` | quiet fills |
| `muted-foreground` | `#607485` | secondary text |
| `border` | `#D8E2EA` | borders and dividers |
| `input` | `#D8E2EA` | input border |
| `ring` | `#2563A6` | focus ring |

## Sidebar tokens

| Token | Value |
| --- | --- |
| `sidebar` | `#123047` |
| `sidebar-foreground` | `#EAF3F8` |
| `sidebar-muted` | `#AFC3D1` |
| `sidebar-hover` | `#1A405B` |
| `sidebar-active` | `#2563A6` |
| `sidebar-border` | `#27485F` |

## Operational status tokens

| Status | Foreground | Soft background | Meaning |
| --- | --- | --- | --- |
| online | `#16A36A` | `#DDF5EA` | reachable and healthy |
| warning | `#E59B22` | `#FFF1D6` | degraded, stale, or attention required |
| offline | `#D64545` | `#FCE3E3` | unreachable or failed |
| maintenance | `#7C5CC4` | `#EEE8FB` | intentionally under maintenance |
| disabled | `#81909C` | `#E8EDF0` | administratively disabled |
| info | `#3B82C4` | `#E3F0FA` | informational state |

## Type, spacing, radius, elevation

```text
font-sans: Inter, ui-sans-serif, system-ui, sans-serif
space: 1=4px, 2=8px, 3=12px, 4=16px, 5=20px, 6=24px, 8=32px, 10=40px, 12=48px
radius-sm: 6px
radius-md: 8px
radius-lg: 10px
radius-xl: 12px
radius-pill: 999px
shadow-card: 0 1px 2px rgba(18,48,71,.04)
shadow-elevated: 0 4px 14px rgba(18,48,71,.08)
shadow-sheet: 0 8px 30px rgba(18,48,71,.12)
```

## Rules

1. Use semantic names in components (`bg-background`, `text-muted-foreground`, `bg-status-online-bg`), not hex literals.
2. Add a token only when an existing token cannot express the meaning and the token is likely to be reused.
3. Do not map status colors into generic `success`, `danger`, or `warning` aliases without preserving the camera-domain names.
4. Do not use `surface-elevated` for the application canvas.

