# Accessibility

Target WCAG 2.2 AA for normal operation.

## Color and contrast

- Body text and UI labels must meet 4.5:1 contrast; large text 3:1.
- Status foregrounds are paired with text/icon and a non-color cue.
- Focus rings use the primary/ring token and remain visible against both surface and sidebar.
- Do not communicate selected, disabled, or stale state through color alone.

## Keyboard and focus

- All actions are reachable in logical order with Tab/Shift+Tab.
- Use `:focus-visible`; never remove the browser focus indicator without a replacement.
- Sheets/dialogs trap focus, close on Escape, and restore focus to the trigger.
- Table row activation has a keyboard equivalent and does not rely on clicking a non-semantic `<div>`.

## Tables and filters

- Use real table semantics and header associations.
- Announce sorting direction and selection state.
- Give every filter a visible label or accessible name.
- Provide a clear-all action and expose the number of active filters.

## Motion and screen readers

- Respect `prefers-reduced-motion`.
- Do not animate status changes in a way that creates a false alarm.
- Use `aria-live="polite"` for non-critical refresh messages and avoid assertive announcements for routine polling.
- Icon-only buttons need an accessible name and a tooltip is supplementary, not the only label.

## Touch and responsive behavior

Interactive targets are at least 44×44 CSS pixels on touch layouts. Avoid horizontal scrolling for the entire page; constrain overflow to the table region when unavoidable.

