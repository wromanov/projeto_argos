import type { CameraStatus } from "../../tokens/status";

export type Camera = {
  id: string;
  name: string;
  ip: string;
  mac?: string;
  manufacturer?: string;
  model?: string;
  location: { site: string; building?: string; floor?: string; area?: string };
  status: CameraStatus;
  lastSeenAt?: string;
  vms?: { name: string; server?: string; streamState: CameraStatus };
  network?: { vlan?: string; switchName?: string; port?: string };
};

