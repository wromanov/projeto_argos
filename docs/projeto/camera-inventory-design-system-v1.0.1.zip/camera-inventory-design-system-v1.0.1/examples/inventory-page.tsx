import { useState } from "react";
import { Camera as CameraIcon, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CameraDetailSheet } from "./components/camera-detail-sheet";
import { CameraTable } from "./components/camera-table";
import { InventoryFilters, type InventoryFilterValues } from "./components/inventory-filters";
import { InventoryKpiCard } from "./components/inventory-kpi-card";
import type { Camera } from "./types/camera";

export function InventoryPage({ cameras }: { cameras: Camera[] }) {
  const [selected, setSelected] = useState<Camera>();
  const [filters, setFilters] = useState<InventoryFilterValues>({ query: "", status: "all", location: "all", manufacturer: "all", onlyAttention: false });
  const normalized = filters.query.trim().toLowerCase();
  const visible = cameras.filter((camera) => {
    const textMatch = !normalized || [camera.name, camera.ip, camera.model, camera.location.site].filter(Boolean).some((value) => value!.toLowerCase().includes(normalized));
    const statusMatch = filters.status === "all" || camera.status === filters.status;
    const locationMatch = filters.location === "all" || camera.location.site === filters.location;
    const manufacturerMatch = filters.manufacturer === "all" || camera.manufacturer === filters.manufacturer;
    const attentionMatch = !filters.onlyAttention || ["warning", "offline"].includes(camera.status);
    return textMatch && statusMatch && locationMatch && manufacturerMatch && attentionMatch;
  });

  return (
    <section className="space-y-6" aria-labelledby="inventory-title">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-sm font-medium text-primary">Operações</p><h1 id="inventory-title" className="mt-1 text-2xl font-bold tracking-tight">Inventário de câmeras</h1><p className="mt-1 text-sm text-muted-foreground">Monitore conectividade, localização e integração com o VMS.</p></div><Button className="gap-2"><Plus aria-hidden="true" className="size-4" /> Nova câmera</Button></div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><InventoryKpiCard label="Total" value={cameras.length} icon={CameraIcon} /><InventoryKpiCard label="Online" value={cameras.filter((camera) => camera.status === "online").length} status="online" /><InventoryKpiCard label="Atenção" value={cameras.filter((camera) => camera.status === "warning").length} status="warning" /><InventoryKpiCard label="Offline" value={cameras.filter((camera) => camera.status === "offline").length} status="offline" /></div>
      <InventoryFilters value={filters} locations={[...new Set(cameras.map((camera) => camera.location.site))]} manufacturers={[...new Set(cameras.map((camera) => camera.manufacturer).filter(Boolean) as string[])]} onChange={setFilters} />
      <CameraTable data={visible} onRowOpen={setSelected} />
      <CameraDetailSheet camera={selected} open={Boolean(selected)} onOpenChange={(open) => { if (!open) setSelected(undefined); }} />
    </section>
  );
}

