# React examples

These examples assume shadcn/ui primitives exist at `@/components/ui/*` and a standard `cn` helper exists at `@/lib/utils`. They are intentionally presentational: pass data and callbacks from the route/container layer.

The examples are templates, not a second component library. Copy them into `components/camera-inventory`, then adapt imports to the target repository's alias and shadcn version.

