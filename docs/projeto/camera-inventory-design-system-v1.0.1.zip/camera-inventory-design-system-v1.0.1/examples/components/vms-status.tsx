import { Server } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CameraStatusBadge } from "./camera-status-badge";
import type { CameraStatus } from "../../tokens/status";

type VmsStatusProps = {
  name?: string;
  server?: string;
  streamState: CameraStatus;
  lastSync?: string;
};

export function VmsStatus({ name, server, streamState, lastSync }: VmsStatusProps) {
  return (
    <Card data-slot="vms-status" className="bg-card shadow-card">
      <CardHeader className="flex flex-row items-center gap-2 pb-3">
        <Server aria-hidden="true" className="size-4 text-primary" />
        <CardTitle className="text-base">VMS</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div className="flex items-center justify-between gap-3">
          <span className="text-muted-foreground">Serviço</span>
          <span className="truncate font-medium">{name || "Não informado"}</span>
        </div>
        <div className="flex items-center justify-between gap-3">
          <span className="text-muted-foreground">Servidor</span>
          <span className="truncate font-medium">{server || "—"}</span>
        </div>
        <div className="flex items-center justify-between gap-3">
          <span className="text-muted-foreground">Stream</span>
          <CameraStatusBadge status={streamState} size="sm" />
        </div>
        {lastSync ? <p className="border-t border-border pt-3 text-xs text-muted-foreground">Última sincronização: {lastSync}</p> : null}
      </CardContent>
    </Card>
  );
}

