import { ChevronRight, MapPin } from "lucide-react";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";

export type LocationCrumb = { label: string; href?: string };

export function LocationBreadcrumb({ items }: { items: LocationCrumb[] }) {
  return (
    <Breadcrumb data-slot="location-breadcrumb" aria-label="Localização">
      <BreadcrumbList>
        <BreadcrumbItem>
          <MapPin aria-hidden="true" className="mr-1 size-3.5 text-muted-foreground" />
        </BreadcrumbItem>
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          return (
            <span key={`${item.label}-${index}`} className="inline-flex items-center gap-2">
              <BreadcrumbSeparator><ChevronRight aria-hidden="true" className="size-3" /></BreadcrumbSeparator>
              <BreadcrumbItem>
                {isLast || !item.href ? <BreadcrumbPage>{item.label}</BreadcrumbPage> : <BreadcrumbLink href={item.href}>{item.label}</BreadcrumbLink>}
              </BreadcrumbItem>
            </span>
          );
        })}
      </BreadcrumbList>
    </Breadcrumb>
  );
}

