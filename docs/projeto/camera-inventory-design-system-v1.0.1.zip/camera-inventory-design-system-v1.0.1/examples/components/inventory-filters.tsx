import { Filter, RotateCcw, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { CameraStatus } from "../../tokens/status";

export type InventoryFilterValues = {
  query: string;
  status: CameraStatus | "all";
  location: string;
  manufacturer: string;
  onlyAttention: boolean;
};

type InventoryFiltersProps = {
  value: InventoryFilterValues;
  locations?: string[];
  manufacturers?: string[];
  onChange: (next: InventoryFilterValues) => void;
};

export function InventoryFilters({ value, locations = [], manufacturers = [], onChange }: InventoryFiltersProps) {
  const hasFilters = value.query || value.status !== "all" || value.location !== "all" || value.manufacturer !== "all" || value.onlyAttention;
  const update = (partial: Partial<InventoryFilterValues>) => onChange({ ...value, ...partial });
  const clear = () => onChange({ query: "", status: "all", location: "all", manufacturer: "all", onlyAttention: false });

  return (
    <div data-slot="inventory-filters" className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-card p-3 shadow-card">
      <div className="relative min-w-[220px] flex-1">
        <Search aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input aria-label="Buscar câmeras" value={value.query} onChange={(event) => update({ query: event.target.value })} placeholder="Buscar por nome, IP ou modelo" className="pl-9" />
      </div>
      <Select value={value.status} onValueChange={(status) => update({ status: status as InventoryFilterValues["status"] })}>
        <SelectTrigger aria-label="Filtrar por status" className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos os status</SelectItem>
          <SelectItem value="online">Online</SelectItem>
          <SelectItem value="warning">Atenção</SelectItem>
          <SelectItem value="offline">Offline</SelectItem>
          <SelectItem value="maintenance">Manutenção</SelectItem>
          <SelectItem value="disabled">Desabilitada</SelectItem>
        </SelectContent>
      </Select>
      <Select value={value.location} onValueChange={(location) => update({ location })}>
        <SelectTrigger aria-label="Filtrar por local" className="w-[150px]"><SelectValue placeholder="Local" /></SelectTrigger>
        <SelectContent><SelectItem value="all">Todos os locais</SelectItem>{locations.map((location) => <SelectItem key={location} value={location}>{location}</SelectItem>)}</SelectContent>
      </Select>
      <Select value={value.manufacturer} onValueChange={(manufacturer) => update({ manufacturer })}>
        <SelectTrigger aria-label="Filtrar por fabricante" className="w-[160px]"><SelectValue placeholder="Fabricante" /></SelectTrigger>
        <SelectContent><SelectItem value="all">Todos os fabricantes</SelectItem>{manufacturers.map((manufacturer) => <SelectItem key={manufacturer} value={manufacturer}>{manufacturer}</SelectItem>)}</SelectContent>
      </Select>
      <Button type="button" variant={value.onlyAttention ? "secondary" : "outline"} className="gap-2" aria-pressed={value.onlyAttention} onClick={() => update({ onlyAttention: !value.onlyAttention })}>
        <Filter aria-hidden="true" className="size-4" /> Atenção
      </Button>
      {hasFilters ? <Button type="button" variant="ghost" className="gap-2 text-muted-foreground" onClick={clear}><RotateCcw aria-hidden="true" className="size-4" /> Limpar</Button> : null}
    </div>
  );
}

