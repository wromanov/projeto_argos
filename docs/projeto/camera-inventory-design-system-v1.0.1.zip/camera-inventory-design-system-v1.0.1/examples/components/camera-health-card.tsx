import { Activity, TrendingDown, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { CameraStatus } from "../../tokens/status";

type CameraHealthCardProps = {
  label: string;
  value: string | number;
  status: CameraStatus;
  helper?: string;
  trend?: { value: string; direction: "up" | "down" };
};

const statusText: Record<CameraStatus, string> = {
  online: "text-status-online",
  warning: "text-status-warning",
  offline: "text-status-offline",
  maintenance: "text-status-maintenance",
  disabled: "text-status-disabled",
  info: "text-status-info",
};

export function CameraHealthCard({ label, value, status, helper, trend }: CameraHealthCardProps) {
  const TrendIcon = trend?.direction === "down" ? TrendingDown : TrendingUp;

  return (
    <Card data-slot="camera-health-card" className="bg-card shadow-card">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
        <Activity aria-hidden="true" className={cn("size-4", statusText[status])} />
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-3">
          <span className={cn("text-[28px] font-bold tracking-tight", statusText[status])}>{value}</span>
          {trend ? (
            <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
              <TrendIcon aria-hidden="true" className="size-3.5" />
              {trend.value}
            </span>
          ) : null}
        </div>
        {helper ? <p className="mt-1 text-xs text-muted-foreground">{helper}</p> : null}
      </CardContent>
    </Card>
  );
}

