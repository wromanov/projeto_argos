import { Copy, Network } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

type NetworkInfoProps = {
  ip?: string;
  mac?: string;
  vlan?: string;
  switchName?: string;
  port?: string;
  lastSeenAt?: string;
  onCopy?: (value: string, label: string) => void;
};

function Detail({ label, value, copyable, onCopy }: { label: string; value?: string; copyable?: boolean; onCopy?: () => void }) {
  return (
    <div className="min-w-0">
      <dt className="text-xs font-medium text-muted-foreground">{label}</dt>
      <dd className="mt-1 flex items-center gap-1 text-sm text-foreground">
        <span className="truncate">{value || "—"}</span>
        {copyable && value ? (
          <Button type="button" variant="ghost" size="icon" className="size-7 shrink-0" aria-label={`Copiar ${label}`} onClick={onCopy}>
            <Copy aria-hidden="true" className="size-3.5" />
          </Button>
        ) : null}
      </dd>
    </div>
  );
}

export function NetworkInfo(props: NetworkInfoProps) {
  return (
    <Card data-slot="network-info" className="bg-card shadow-card">
      <CardHeader className="flex flex-row items-center gap-2 pb-3">
        <Network aria-hidden="true" className="size-4 text-primary" />
        <CardTitle className="text-base">Rede</CardTitle>
      </CardHeader>
      <CardContent>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-4 text-sm">
          <Detail label="IP" value={props.ip} copyable onCopy={() => props.onCopy?.(props.ip!, "IP")} />
          <Detail label="MAC" value={props.mac} copyable onCopy={() => props.onCopy?.(props.mac!, "MAC")} />
          <Detail label="VLAN" value={props.vlan} />
          <Detail label="Switch" value={props.switchName} />
          <Detail label="Porta" value={props.port} />
          <Detail label="Último contato" value={props.lastSeenAt} />
        </dl>
      </CardContent>
    </Card>
  );
}

