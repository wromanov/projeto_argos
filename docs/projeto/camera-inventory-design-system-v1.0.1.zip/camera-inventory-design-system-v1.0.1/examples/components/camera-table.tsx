import { useMemo, useState } from "react";
import {
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CameraStatusBadge } from "./camera-status-badge";
import type { Camera } from "../types/camera";

type CameraTableProps = {
  data: Camera[];
  onRowOpen?: (camera: Camera) => void;
};

export function CameraTable({ data, onRowOpen }: CameraTableProps) {
  const columns = useMemo<ColumnDef<Camera>[]>(() => [
    {
      accessorKey: "name",
      header: ({ column }) => <Button variant="ghost" className="-ml-3 h-8 gap-1 px-3 text-xs font-semibold" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
        Câmera <ArrowUpDown aria-hidden="true" className="size-3.5" />
      </Button>,
      cell: ({ row }) => <div><div className="font-medium text-foreground">{row.original.name}</div><div className="text-xs text-muted-foreground">{row.original.ip}</div></div>,
    },
    { accessorKey: "location.site", header: "Local", cell: ({ row }) => <span className="text-sm">{row.original.location.site}</span> },
    { accessorKey: "model", header: "Modelo", cell: ({ row }) => <span className="text-sm text-muted-foreground">{row.original.model || "—"}</span> },
    { accessorKey: "lastSeenAt", header: "Último contato", cell: ({ row }) => <span className="text-sm text-muted-foreground">{row.original.lastSeenAt || "—"}</span> },
    { accessorKey: "status", header: "Status", cell: ({ row }) => <CameraStatusBadge status={row.original.status} size="sm" /> },
  ], []);

  const [sorting, setSorting] = useState<SortingState>([]);
  const table = useReactTable({ data, columns, state: { sorting }, onSortingChange: setSorting, getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(), getPaginationRowModel: getPaginationRowModel() });

  return (
    <div data-slot="camera-table" className="overflow-hidden rounded-lg border border-border bg-card shadow-card">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-muted/40"><TableRow>{table.getHeaderGroups().map((group) => group.headers.map((header) => <TableHead key={header.id}>{header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}</TableHead>))}</TableRow></TableHeader>
          <TableBody>
            {table.getRowModel().rows.length ? table.getRowModel().rows.map((row) => <TableRow key={row.id} tabIndex={0} className="h-14 cursor-pointer focus-visible:bg-secondary/60" onClick={() => onRowOpen?.(row.original)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); onRowOpen?.(row.original); } }} aria-label={`Abrir ${row.original.name}`}>
              {row.getVisibleCells().map((cell) => <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>)}
            </TableRow>) : <TableRow><TableCell colSpan={columns.length} className="h-24 text-center text-sm text-muted-foreground">Nenhuma câmera encontrada.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-between border-t border-border px-4 py-3 text-xs text-muted-foreground">
        <span>{data.length} resultado(s)</span>
        <div className="flex items-center gap-1"><Button variant="ghost" size="icon" className="size-8" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()} aria-label="Página anterior"><ChevronLeft aria-hidden="true" className="size-4" /></Button><span>{table.getState().pagination.pageIndex + 1}</span><Button variant="ghost" size="icon" className="size-8" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()} aria-label="Próxima página"><ChevronRight aria-hidden="true" className="size-4" /></Button></div>
      </div>
    </div>
  );
}
