import {
  AlertTriangle,
  CheckCircle2,
  CircleOff,
  Info,
  Wrench,
  XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { CameraStatus } from "../../tokens/status";
import { cameraStatusMeta } from "../../tokens/status";

const iconMap = {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Wrench,
  CircleOff,
  Info,
};

const toneClasses: Record<CameraStatus, string> = {
  online: "bg-status-online-bg text-status-online border-transparent",
  warning: "bg-status-warning-bg text-status-warning border-transparent",
  offline: "bg-status-offline-bg text-status-offline border-transparent",
  maintenance:
    "bg-status-maintenance-bg text-status-maintenance border-transparent",
  disabled: "bg-status-disabled-bg text-status-disabled border-transparent",
  info: "bg-status-info-bg text-status-info border-transparent",
};

type CameraStatusBadgeProps = {
  status: CameraStatus;
  label?: string;
  showIcon?: boolean;
  size?: "sm" | "default";
  className?: string;
};

export function CameraStatusBadge({
  status,
  label,
  showIcon = true,
  size = "default",
  className,
}: CameraStatusBadgeProps) {
  const meta = cameraStatusMeta[status];
  const Icon = iconMap[meta.icon];

  return (
    <Badge
      data-slot="camera-status-badge"
      data-status={status}
      aria-label={label ?? meta.label}
      className={cn(
        "gap-1.5 rounded-pill font-medium",
        toneClasses[status],
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs",
        className,
      )}
    >
      {showIcon ? <Icon aria-hidden="true" className="size-3.5" /> : null}
      <span>{label ?? meta.label}</span>
    </Badge>
  );
}

