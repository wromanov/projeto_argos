import type { LucideIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { CameraStatus } from "../../tokens/status";

type InventoryKpiCardProps = {
  label: string;
  value: string | number;
  description?: string;
  icon?: LucideIcon;
  status?: CameraStatus;
  compact?: boolean;
};

const statusText: Record<CameraStatus, string> = {
  online: "text-status-online",
  warning: "text-status-warning",
  offline: "text-status-offline",
  maintenance: "text-status-maintenance",
  disabled: "text-status-disabled",
  info: "text-status-info",
};

export function InventoryKpiCard({
  label,
  value,
  description,
  icon: Icon,
  status,
  compact = false,
}: InventoryKpiCardProps) {
  return (
    <Card data-slot="inventory-kpi-card" className="border-border bg-card shadow-card">
      <CardHeader className={cn("flex flex-row items-center justify-between space-y-0", compact ? "pb-2" : "pb-3")}>
        <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
        {Icon ? <Icon aria-hidden="true" className="size-4 text-muted-foreground" /> : null}
      </CardHeader>
      <CardContent>
        <p className={cn("font-bold tracking-tight", compact ? "text-2xl" : "text-[28px]", status && statusText[status])}>
          {value}
        </p>
        {description ? <p className="mt-1 text-xs text-muted-foreground">{description}</p> : null}
      </CardContent>
    </Card>
  );
}

