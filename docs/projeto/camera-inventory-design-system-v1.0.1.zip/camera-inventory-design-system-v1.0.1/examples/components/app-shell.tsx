import type { ReactNode } from "react";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

type AppShellProps = {
  sidebar: ReactNode;
  topbar?: ReactNode;
  children: ReactNode;
};

export function AppShell({ sidebar, topbar, children }: AppShellProps) {
  return (
    <div data-slot="app-shell" className="min-h-screen bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 hidden w-60 border-r border-sidebar-border bg-sidebar text-sidebar-foreground lg:block">
        {sidebar}
      </aside>
      <div className="lg:pl-60">
        <header className="sticky top-0 z-20 flex min-h-16 items-center gap-3 border-b border-border bg-card/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-card/80 lg:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Abrir navegação"><Menu aria-hidden="true" className="size-5" /></Button>
          {topbar}
        </header>
        <main className="p-4 lg:p-6">{children}</main>
      </div>
    </div>
  );
}

