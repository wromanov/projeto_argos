import { Camera as CameraIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { CameraStatusBadge } from "./camera-status-badge";
import { LocationBreadcrumb } from "./location-breadcrumb";
import { NetworkInfo } from "./network-info";
import { VmsStatus } from "./vms-status";
import type { Camera } from "../types/camera";

type CameraDetailSheetProps = { camera?: Camera; open: boolean; onOpenChange: (open: boolean) => void; onEdit?: (camera: Camera) => void };

export function CameraDetailSheet({ camera, open, onOpenChange, onEdit }: CameraDetailSheetProps) {
  if (!camera) return null;
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent data-slot="camera-detail-sheet" className="w-full overflow-y-auto border-l border-border bg-background sm:max-w-xl">
        <SheetHeader className="text-left"><div className="mb-2 flex items-center gap-2"><CameraIcon aria-hidden="true" className="size-5 text-primary" /><Badge variant="secondary">{camera.model || "Câmera"}</Badge></div><SheetTitle>{camera.name}</SheetTitle><SheetDescription>{camera.ip} · {camera.manufacturer || "Fabricante não informado"}</SheetDescription></SheetHeader>
        <div className="mt-6 space-y-6">
          <div className="flex items-center justify-between gap-3"><CameraStatusBadge status={camera.status} /><button type="button" className="text-sm font-medium text-primary hover:underline" onClick={() => onEdit?.(camera)}>Abrir detalhes completos</button></div>
          <LocationBreadcrumb items={[{ label: camera.location.site }, ...(camera.location.building ? [{ label: camera.location.building }] : []), ...(camera.location.floor ? [{ label: camera.location.floor }] : []), ...(camera.location.area ? [{ label: camera.location.area }] : [])]} />
          <Separator />
          <div className="grid gap-4 sm:grid-cols-2"><NetworkInfo ip={camera.ip} mac={camera.mac} vlan={camera.network?.vlan} switchName={camera.network?.switchName} port={camera.network?.port} lastSeenAt={camera.lastSeenAt} /><VmsStatus name={camera.vms?.name} server={camera.vms?.server} streamState={camera.vms?.streamState || "info"} /></div>
          <div className="rounded-lg border border-border bg-card p-4 text-sm"><h3 className="font-semibold">Identificação</h3><dl className="mt-3 grid grid-cols-2 gap-3"><div><dt className="text-xs text-muted-foreground">ID</dt><dd className="mt-1 font-medium">{camera.id}</dd></div><div><dt className="text-xs text-muted-foreground">Modelo</dt><dd className="mt-1 font-medium">{camera.model || "—"}</dd></div></dl></div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

