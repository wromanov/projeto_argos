# Camera Inventory Design System v1.0.1

**Status:** `VISUAL_BASELINE_APPROVED`  
**Audience:** product engineers, designers, Codex/vibe-coding agents  
**Primary language:** English identifiers with Portuguese-friendly UI copy support

## 1. Objective

Create a coherent, calm, information-dense interface for camera inventory, health, network, VMS, and location operations. Users should be able to identify the current state of a camera within a few seconds, move from a list to details without losing context, and distinguish operational alerts from ordinary product decoration.

## 2. Visual principles

The interface must communicate infrastructure, reliability, technology, and high legibility. It uses moderate density, clear hierarchy, restrained elevation, and semantic status color.

Avoid:

- pure black or pure white as the dominant application palette;
- decorative gradients, neon, cyberpunk, or gamer styling;
- strong shadows and excessive rounded corners;
- oversized controls that reduce table density;
- red, green, amber, or purple for non-semantic decoration;
- page-specific one-off colors or typography values.

## 3. Stack contract

| Concern | Decision |
| --- | --- |
| UI primitives | shadcn/ui (owned source code) |
| Styling | Tailwind CSS + CSS variables |
| Font | Inter, with system sans fallback |
| Icons | Lucide React; icons must have a meaningful label or be decorative |
| Data table | TanStack Table on top of shadcn Table |
| Framework | React + TypeScript |
| Full alternative UI library | Not allowed by default |

## 4. Layout contract

```text
AppShell
├── Sidebar (224–240px desktop)
├── Main
│   ├── Topbar (60–64px)
│   └── PageContent (24–32px page padding)
└── Optional CameraDetailSheet
```

Desktop sidebars may collapse to 68–76px only when tooltips and accessible labels are provided. On small screens the sidebar becomes a sheet or drawer. The main content must remain usable at 320px CSS width.

## 5. Typography contract

Use Inter. Page titles are 28px/700, section titles 20px/600, metric values 28–32px/700, body 14px/400, labels 14px/500, table headers 12–13px/600, captions 12px/400. Never use more than two text weights within a compact card unless the hierarchy requires it.

## 6. Spacing and shape

Use the 4px base scale: 4, 8, 12, 16, 20, 24, 32, 40, 48. Page padding is 24px desktop and 16px mobile. Cards use 16–20px inner padding. Tables use 52–56px rows. Buttons and inputs use an 8px radius; cards 10–12px; status badges are pill-shaped.

## 7. Color semantics

Brand and structure use background `#F4F7FA`, foreground `#172B3A`, surface `#FAFCFE`, primary `#2563A6`, primary hover `#1D4F86`, secondary `#E8F2FA`, teal accent `#DFF3F2` / `#0F6F71`, sidebar `#123047` / `#1A405B`, and border `#D8E2EA`.

Operational status colors are reserved for meaning: online `#16A36A`, warning `#E59B22`, offline `#D64545`, maintenance `#7C5CC4`, disabled `#81909C`, and info `#3B82C4`. Every status must also have text or an icon; color alone is never sufficient.

## 8. Interaction principles

- Prefer a detail sheet for quick inspection and a routed detail page for deep editing.
- Keep filters visible above the table and preserve them when a detail sheet opens.
- Use confirmation for destructive actions and an undo path where feasible.
- Make loading, empty, error, and stale-data states explicit.
- Avoid hover-only actions; provide keyboard and touch equivalents.

## 9. Non-goals

This package does not define backend data contracts, authorization policy, camera streaming protocols, or a replacement for a product-specific content style guide. It defines the visual and interaction surface that those systems consume.

