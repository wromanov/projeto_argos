# Product Design Context

This file records the Product Design grounding used for this package. It is deliberately concise so an agent can load it without re-reading the entire conversation.

## Product

Web application for inventory, health, network, VMS, and location management of CCTV cameras. The dominant workflow is operational lookup: find a camera, understand its current state, inspect details, and take the next action.

## Approved visual direction

Corporate Tech / Infrastructure. The interface should feel like a modern infrastructure console: calm, dense enough for daily operations, and immediately legible. Use the cleanliness of shadcn/ui without preserving its default black/white look.

## Baseline evidence

- Source: referenced ChatGPT conversation `Pesquisar Design Systems` (`6ab2e908-d0d8-83e9-8d99-33b308244d19`).
- Approved direction in source: petrol-blue sidebar, blue-gray canvas, corporate blue primary, teal accent, semantic status colors, Inter, Lucide, shadcn/ui, TanStack Table.
- Image asset: referenced in the source conversation but not available as a local file in this workspace. The package uses the written baseline as the durable source of truth and avoids claiming pixel-perfect image extraction.

## Product design decisions

1. Operational status colors are exclusive to state and feedback.
2. Tables, filters, badges, sheets, and breadcrumbs are first-class patterns.
3. A detail sheet keeps list context; a route is reserved for deep editing.
4. Components are presentational and typed; data fetching stays in route/container code.
5. Agents must reuse tokens and finite variants rather than improvising a visual language.

## Design review prompt

Before accepting a screen, compare it against `DESIGN_TOKENS.md`, `PAGE_PATTERNS.md`, and `VISUAL_ACCEPTANCE_CHECKLIST.md`. If an image reference becomes available later, use it to refine spacing and composition while preserving the semantic contract in these files.

