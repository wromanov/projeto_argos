# AI Implementation Rules

These rules are the guardrail for Codex and other vibe-coding agents. They are intentionally explicit so visual consistency does not depend on model memory.

## Required order of work

1. Read `DESIGN_TOKENS.md` and the target pattern in `PAGE_PATTERNS.md`.
2. Search the repository for an existing shadcn primitive or domain component.
3. Reuse or extend an existing component before creating a new one.
4. Implement the semantic states and responsive behavior before polishing copy.
5. Run the visual acceptance checklist and accessibility checks.

## Hard constraints

- Never invent a hex color, font, shadow, radius, or spacing value in a screen component.
- Never import MUI, Ant Design, Chakra, or another full UI kit without a written capability-gap decision.
- Never make status color the only status signal.
- Never replace the sidebar or page canvas with black, white, gradients, or neon.
- Never create a one-off `CameraRow` when `CameraTable` can express the need.
- Never fetch data inside presentational domain components.
- Never remove loading, empty, error, or disabled states to “finish faster”.
- Never use hover-only controls for an essential action.

## Decision hierarchy

When a requirement is underspecified, choose in this order:

1. Existing component API in the repository.
2. This package's domain component contract.
3. Existing semantic token.
4. Closest page pattern.
5. Ask for clarification before adding a new system-level token or variant.

## Output requirements for agent-generated UI

Every implementation response should identify the reused tokens/components, list any new variant, and state whether the acceptance checklist passed. If a new token is genuinely required, propose its name, value, semantic purpose, and impact before silently adding it.

## Copy and localization

Keep labels short and operational. Use stable message keys for production copy. Do not encode status in English-only text; status labels must be localizable and paired with a stable enum.

## Review prompt

Before handoff, ask: “Could another agent implement the same screen from the tokens and pattern without guessing?” If no, update the contract or examples instead of adding page-specific styling.

