export const CAMERA_STATUSES = [
  "online",
  "warning",
  "offline",
  "maintenance",
  "disabled",
  "info",
] as const;

export type CameraStatus = (typeof CAMERA_STATUSES)[number];

export const cameraStatusMeta: Record<
  CameraStatus,
  { label: string; colorToken: string; backgroundToken: string; icon: "CheckCircle2" | "AlertTriangle" | "XCircle" | "Wrench" | "CircleOff" | "Info" }
> = {
  online: {
    label: "Online",
    colorToken: "status-online",
    backgroundToken: "status-online-bg",
    icon: "CheckCircle2",
  },
  warning: {
    label: "Atenção",
    colorToken: "status-warning",
    backgroundToken: "status-warning-bg",
    icon: "AlertTriangle",
  },
  offline: {
    label: "Offline",
    colorToken: "status-offline",
    backgroundToken: "status-offline-bg",
    icon: "XCircle",
  },
  maintenance: {
    label: "Manutenção",
    colorToken: "status-maintenance",
    backgroundToken: "status-maintenance-bg",
    icon: "Wrench",
  },
  disabled: {
    label: "Desabilitada",
    colorToken: "status-disabled",
    backgroundToken: "status-disabled-bg",
    icon: "CircleOff",
  },
  info: {
    label: "Informação",
    colorToken: "status-info",
    backgroundToken: "status-info-bg",
    icon: "Info",
  },
};

