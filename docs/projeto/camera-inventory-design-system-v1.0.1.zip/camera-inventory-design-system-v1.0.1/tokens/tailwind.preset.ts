import type { Config } from "tailwindcss";

/**
 * Add this preset to a Tailwind config, or copy the theme entries into a
 * Tailwind v4 @theme block. Components should use semantic names, not hex.
 */
const cameraInventoryPreset = {
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background))",
          foreground: "hsl(var(--sidebar-foreground))",
          primary: "hsl(var(--sidebar-primary))",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground))",
          accent: "hsl(var(--sidebar-accent))",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground))",
          border: "hsl(var(--sidebar-border))",
          ring: "hsl(var(--sidebar-ring))",
        },
        "status-online": "var(--status-online)",
        "status-online-bg": "var(--status-online-bg)",
        "status-warning": "var(--status-warning)",
        "status-warning-bg": "var(--status-warning-bg)",
        "status-offline": "var(--status-offline)",
        "status-offline-bg": "var(--status-offline-bg)",
        "status-maintenance": "var(--status-maintenance)",
        "status-maintenance-bg": "var(--status-maintenance-bg)",
        "status-disabled": "var(--status-disabled)",
        "status-disabled-bg": "var(--status-disabled-bg)",
        "status-info": "var(--status-info)",
        "status-info-bg": "var(--status-info-bg)",
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      borderRadius: {
        sm: "6px",
        md: "8px",
        lg: "var(--radius)",
        xl: "12px",
        pill: "999px",
      },
      boxShadow: {
        card: "var(--shadow-card)",
        elevated: "var(--shadow-elevated)",
        sheet: "var(--shadow-sheet)",
      },
      minHeight: {
        touch: "44px",
      },
    },
  },
} satisfies Pick<Config, "theme">;

export default cameraInventoryPreset;

