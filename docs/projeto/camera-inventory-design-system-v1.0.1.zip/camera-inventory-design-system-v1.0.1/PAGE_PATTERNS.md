# Page Patterns

## Pattern A — Operations dashboard

```text
PageHeader (title, description, primary action)
└── KPI grid (Total, Online, Attention, Offline)
    ├── Health summary / trend card
    └── Attention table or “needs action” list
```

Use four KPI cards at desktop, two columns at tablet, and a single column at narrow widths. Keep the most actionable metric first. Do not make charts the only representation of a status count.

## Pattern B — Inventory list

```text
PageHeader
└── InventoryFilters
    └── CameraTable
        ├── row selection / bulk toolbar (optional)
        └── pagination + visible result count
```

The table container uses `surface` and a subtle border. Filters remain above the table. Row activation opens `CameraDetailSheet` while preserving the route and filter state. Sorting and filtering state should be URL-serializable for shareable views.

## Pattern C — Camera detail

Use a routed page for edits and an optional sheet for inspection. The first viewport should expose identity, current status, location, network summary, and VMS status. Group secondary metadata below a divider instead of creating many small cards.

## Pattern D — Empty, loading, and failure

- Loading: skeleton rows/cards that preserve the final layout.
- Empty: explain why there are no results and provide a clear filter action.
- Error: concise message, retry action, and a support/correlation reference when available.
- Stale: show last-sync time and warning semantics; never silently present stale health as current.

## Responsive behavior

At 1024px, reduce table columns before reducing type. At 768px, collapse sidebar and move filters into a wrap/overflow-safe toolbar. At 640px, use cards or a two-line row representation rather than horizontal page scrolling. At 320px, preserve action targets at least 44px high.

