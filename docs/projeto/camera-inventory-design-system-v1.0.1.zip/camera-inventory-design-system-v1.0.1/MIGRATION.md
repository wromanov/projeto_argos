# Adoption and Migration

## New project

1. Initialize shadcn/ui and Tailwind.
2. Install Inter, Lucide React, and TanStack Table.
3. Copy `tokens/camera-inventory.css` to the global stylesheet.
4. Register `tokens/tailwind.preset.ts` or copy its semantic mappings.
5. Add primitives first, then domain components from `examples/components`.
6. Implement the inventory list before dashboard embellishments; it validates density and status semantics early.

## Existing shadcn project

1. Snapshot the current UI and inventory routes.
2. Replace only global variables first; do not rewrite every component at once.
3. Map existing `destructive` usage to `status-offline` only where the meaning is operational.
4. Introduce the sidebar variables and update navigation states.
5. Migrate repeated camera rows to `CameraTable` and repeated badges to `CameraStatusBadge`.
6. Move detail dialogs to `CameraDetailSheet` and verify focus restoration.
7. Run the acceptance checklist at each route boundary.

## Existing non-shadcn project

Keep the product data and routes. Introduce the token layer and a thin adapter for the existing primitives, then migrate one vertical slice (inventory list + detail) before removing the old visual system. Do not mix two full UI kits in the same feature.

## Rollback

Token changes are reversible: restore the previous global stylesheet and leave domain components isolated under their own namespace. Keep the package version in the repository so an agent can identify which contract a screen followed.

